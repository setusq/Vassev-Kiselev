import matplotlib.pyplot as plt #Импортируем библиотеку
import numpy as np

X = [0, 0, 19, 35, 14] #Координаты точек по X
Y = [28.2, 17, 0, 0, 17] #Координаты точек по Y
plt.scatter(X, Y) #отрисовываем точки

plt.xlim(0,50) #Ограничения по Х
plt.ylim(0,50) #Ограничения по Y
plt.yticks(range(0, 50, 4))
plt.xticks(range(0, 50, 4))


plt.title('График Васев Киселев') #название графика
plt.xlabel('Значение Х') #подпись оси
plt.ylabel('Значение Y') #подпись оси
plt.plot([0, 35], [28.2, 0]) #наклонная
plt.fill_between([14, 19], [17, 13], color='cyan')
plt.fill_between([0, 14], [17, 17], color='cyan')

plt.plot([0, 5], [4, 0], color='red') #Параллельная наклонная
plt.axhline(y=17, color='green', linestyle='--') #пунктирная горизонтальная
plt.axvline(x=19) #пунктирная вертикальная
plt.axvline(x=14, color='green', linestyle='--') #пунктирная горизонтальная
plt.grid()
plt.arrow(5, 0, 3, 5, width=0.2, color='red') #Координаты стрелки
plt.show() #отрисовываем весь график
